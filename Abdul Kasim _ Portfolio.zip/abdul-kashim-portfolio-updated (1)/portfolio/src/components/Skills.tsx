import React from 'react';
import { motion } from 'motion/react';
import { Globe, Database, Brain, Layout, BarChart, Server } from 'lucide-react';

const skillCategories = [
  {
    title: 'Frontend Development',
    icon: Layout,
    skills: ['React.js', 'TypeScript', 'Tailwind CSS', 'HTML5/CSS3', 'Next.js'],
  },
  {
    title: 'Backend & Systems',
    icon: Server,
    skills: ['Node.js', 'Express', 'Django', 'Flask', 'REST APIs'],
  },
  {
    title: 'AI & Machine Learning',
    icon: Brain,
    skills: ['TensorFlow', 'PyTorch', 'Scikit-learn', 'Computer Vision', 'NLP'],
  },
  {
    title: 'Data Science & Analytics',
    icon: BarChart,
    skills: ['Python', 'Pandas', 'NumPy', 'D3.js', 'SQL'],
  },
  {
    title: 'Databases & Tools',
    icon: Database,
    skills: ['PostgreSQL', 'MongoDB', 'Docker', 'Git/GitHub', 'Kafka'],
  },
];

export const Skills = () => {
  return (
    <section id="skills" className="py-24">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-display font-bold mb-4">Technical Prowess</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            A comprehensive set of tools and technologies I use to build 
            modern, scalable, and intelligent software.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((category, idx) => (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              viewport={{ once: true }}
              className="p-8 rounded-3xl bg-brand-bg-lighter border border-white/5 hover:border-brand-accent/40 transition-all group"
            >
              <div className="w-14 h-14 rounded-2xl bg-brand-accent/10 flex items-center justify-center mb-6 group-hover:bg-brand-accent/20 transition-colors">
                <category.icon className="text-brand-accent" size={28} />
              </div>
              <h3 className="text-xl font-display font-bold mb-6 text-white">{category.title}</h3>
              <div className="flex flex-wrap gap-2">
                {category.skills.map((skill) => (
                  <span 
                    key={skill}
                    className="px-3 py-1 rounded-full bg-white/5 text-gray-300 text-xs border border-white/10 hover:border-brand-accent/50 transition-colors"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
