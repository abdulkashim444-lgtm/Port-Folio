import React from 'react';
import { motion } from 'motion/react';
import { ExternalLink, Github } from 'lucide-react';

const projects = [
  {
    title: 'AI-Powered Fake News Detection System',
    description: 'An end-to-end system using machine learning and NLP to identify fraudulent news with 85% accuracy. Features a real-time RESTful API and responsive React interface.',
    image: 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&q=80&w=800',
    tech: ['Python', 'Flask', 'NLP', 'React', 'Scikit-learn'],
    github: 'https://github.com/abdulkashim444-lgtm/AI-FakeNews-Detector',
    live: '#',
  },
  {
    title: 'Real-Time Data Analytics Dashboard',
    description: 'Full-stack analytics platform processing thousands of daily data points. Implemented automated ETL processes and dynamic D3.js visualizations.',
    image: 'https://images.unsplash.com/photo-1551288049-bbbda536339a?auto=format&fit=crop&q=80&w=800',
    tech: ['Python', 'Pandas', 'D3.js', 'React', 'PostgreSQL'],
    github: '#',
    live: '#',
  },
  {
    title: 'Computer Vision Object Detection System',
    description: 'Real-time object detection using YOLO architecture, achieving 20 FPS on standard hardware. Optimized for inference using TensorRT.',
    image: 'https://images.unsplash.com/photo-1527430253228-e92688e1ad3a?auto=format&fit=crop&q=80&w=800',
    tech: ['YOLOv8', 'TensorRT', 'OpenCV', 'Python', 'React'],
    github: 'https://github.com/abdulkashim444-lgtm/Computer-Vision-Object-Detection-System',
    live: '#',
  },
];

export const Projects = () => {
  return (
    <section id="projects" className="py-24 bg-brand-bg-lighter/20">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-4xl font-display font-bold mb-16 text-center">Featured Projects</h2>
        
        <div className="space-y-24">
          {projects.map((project, idx) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className={`flex flex-col ${idx % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'} gap-12 items-center`}
            >
              <div className="flex-1 group relative">
                <div className="absolute -inset-2 bg-gradient-to-r from-brand-accent to-blue-500 rounded-3xl blur opacity-20 group-hover:opacity-40 transition-opacity" />
                <div className="relative rounded-3xl overflow-hidden aspect-video border border-white/10">
                  <img 
                    src={project.image} 
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
              </div>

              <div className="flex-1 space-y-6">
                <h3 className="text-3xl font-display font-bold text-white">{project.title}</h3>
                <p className="text-gray-400 text-lg leading-relaxed">{project.description}</p>
                <div className="flex flex-wrap gap-2">
                  {project.tech.map((t) => (
                    <span key={t} className="px-3 py-1 rounded-full bg-brand-accent/5 text-brand-accent text-sm border border-brand-accent/20">
                      {t}
                    </span>
                  ))}
                </div>
                <div className="flex gap-4 pt-4">
                  <a href={project.github} className="flex items-center gap-2 text-white hover:text-brand-accent transition-colors">
                    <Github size={20} /> Code
                  </a>
                  <a href={project.live} className="flex items-center gap-2 text-white hover:text-brand-accent transition-colors">
                    <ExternalLink size={20} /> Live Demo
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-20 text-center">
           <a href="https://github.com/abdulkashim444-lgtm" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-brand-accent font-semibold hover:gap-4 transition-all">
             View More on GitHub <ArrowRight size={20} />
           </a>
        </div>
      </div>
    </section>
  );
};

const ArrowRight = ({ size }: { size: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M5 12h14M12 5l7 7-7 7" />
  </svg>
);
