import React from 'react';
import { motion } from 'motion/react';
import { Mail, Github, Linkedin, Instagram, Send } from 'lucide-react';

export const Contact = () => {
  return (
    <section id="contact" className="py-24 bg-brand-bg-lighter/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-display font-bold mb-6">Let's Connect.</h2>
            <p className="text-gray-400 text-lg mb-10 max-w-md">
              I'm currently looking for new opportunities and collaborations. 
              Whether you have a question or just want to say hi, I'll try my best to get back to you!
            </p>
            
            <div className="space-y-6">
              <a href="mailto:abdulkashim444@gmail.com" className="flex items-center gap-4 group">
                <div className="w-12 h-12 rounded-xl bg-brand-accent/10 flex items-center justify-center group-hover:bg-brand-accent transition-colors">
                  <Mail className="text-brand-accent group-hover:text-white" size={24} />
                </div>
                <div>
                   <p className="text-sm text-gray-500 uppercase tracking-widest font-semibold">Email Me</p>
                   <p className="text-white font-medium">abdulkashim444@gmail.com</p>
                </div>
              </a>
              
              <div className="flex gap-4 pt-6">
                {[
                  { icon: Github, href: 'https://github.com/abdulkashim444-lgtm' },
                  { icon: Linkedin, href: 'https://www.linkedin.com/in/abdul-kashim-567984332' },
                  { icon: Instagram, href: '#' },
                ].map((social, i) => (
                  <a 
                    key={i} 
                    href={social.href}
                    className="w-12 h-12 rounded-xl bg-brand-bg-lighter border border-white/5 flex items-center justify-center hover:border-brand-accent hover:text-brand-accent transition-all text-gray-400"
                  >
                    <social.icon size={20} />
                  </a>
                ))}
              </div>
            </div>
          </motion.div>

          <motion.form
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="p-8 rounded-3xl bg-brand-bg-lighter border border-white/5 space-y-6"
            onSubmit={(e) => e.preventDefault()}
          >
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-400 ml-1">Full Name</label>
              <input 
                type="text" 
                placeholder="John Doe"
                className="w-full px-6 py-4 rounded-xl bg-brand-bg border border-white/10 focus:border-brand-accent/50 outline-none transition-all placeholder:text-gray-600"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-400 ml-1">Email Address</label>
              <input 
                type="email" 
                placeholder="john@example.com"
                className="w-full px-6 py-4 rounded-xl bg-brand-bg border border-white/10 focus:border-brand-accent/50 outline-none transition-all placeholder:text-gray-600"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-400 ml-1">Message</label>
              <textarea 
                rows={5}
                placeholder="How can I help you?"
                className="w-full px-6 py-4 rounded-xl bg-brand-bg border border-white/10 focus:border-brand-accent/50 outline-none transition-all placeholder:text-gray-600 resize-none"
              />
            </div>
            <button className="w-full py-4 rounded-xl bg-brand-accent text-white font-bold flex items-center justify-center gap-2 hover:shadow-[0_0_20px_rgba(255,107,87,0.4)] transition-all">
              Send Message <Send size={20} />
            </button>
          </motion.form>
        </div>
      </div>
    </section>
  );
};

export const Footer = () => {
  return (
    <footer className="py-12 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
        <div className="text-center md:text-left">
          <h3 className="text-2xl font-display font-bold text-brand-accent mb-2">AK.</h3>
          <p className="text-gray-500 text-sm">© 2026 Abdul Kashim. All rights reserved.</p>
        </div>
        
        <div className="flex gap-8 text-gray-400 text-sm font-medium">
          <a href="#home" className="hover:text-brand-accent transition-colors">Home</a>
          <a href="#about" className="hover:text-brand-accent transition-colors">About</a>
          <a href="#projects" className="hover:text-brand-accent transition-colors">Projects</a>
          <a href="#contact" className="hover:text-brand-accent transition-colors">Contact</a>
        </div>
        
        <p className="text-gray-500 text-sm italic">
          Designed & Developed with ❤️ by Abdul Kashim
        </p>
      </div>
    </footer>
  );
};
