import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Download, ChevronDown, Briefcase, GraduationCap, Award, Code2, X } from 'lucide-react';

const resumeSections = [
  {
    id: 'education',
    icon: GraduationCap,
    title: 'Education',
    items: [
      {
        heading: 'OP Jindal University',
        subheading: 'B.Tech – Computer Science & Engineering',
        period: 'Aug 2024 – Present',
        detail: 'GPA: 8.56/10.0 · DSA, ML, AI, DBMS, OOP, Web Tech, Computer Networks',
      },
    ],
  },
  {
    id: 'experience',
    icon: Briefcase,
    title: 'Experience',
    items: [
      {
        heading: 'Front End Developer Intern',
        subheading: 'Apexsquare Solutions',
        period: 'Apr 2026 – May 2026',
        detail: 'Built responsive web interfaces with React.js, integrated REST APIs, and optimised performance across desktop & mobile.',
      },
      {
        heading: 'Artificial Intelligence Intern',
        subheading: 'Alfido Tech',
        period: 'Mar 2026 – Apr 2026',
        detail: 'Applied Python, Pandas, NumPy, and Scikit-learn for EDA and predictive modelling on real-world AI tasks.',
      },
      {
        heading: 'Software Engineering Virtual Experience',
        subheading: 'JPMorgan Chase & Co. (Forage)',
        period: '2026',
        detail: 'REST API integration, Kafka event streaming, backend service implementation & Agile workflows.',
      },
      {
        heading: 'Data Analytics Virtual Intern',
        subheading: 'Quantium (Forage)',
        period: '2026',
        detail: 'Customer segmentation, statistical store-trial analysis, and executive-level insights using the Pyramid Principle.',
      },
    ],
  },
  {
    id: 'projects',
    icon: Code2,
    title: 'Key Projects',
    items: [
      {
        heading: 'AI-Powered Fake News Detection System',
        subheading: 'Python · Flask · NLP · React · Scikit-learn',
        period: '',
        detail: '85% accuracy in identifying fraudulent news; 500ms prediction response after optimisation.',
      },
      {
        heading: 'Real-Time Data Analytics Dashboard',
        subheading: 'Python · Pandas · D3.js · PostgreSQL',
        period: '',
        detail: 'Full-stack ETL pipeline; D3.js visualisations enabling 95% faster data-driven decisions.',
      },
      {
        heading: 'Computer Vision Object Detection System',
        subheading: 'YOLOv8 · TensorRT · OpenCV · Python',
        period: '',
        detail: '20 FPS real-time detection; 81% model-size reduction via TensorRT quantisation.',
      },
    ],
  },
  {
    id: 'certifications',
    icon: Award,
    title: 'Certifications',
    items: [
      { heading: 'Quantium Data Analytics Job Simulation', subheading: 'Forage', period: '2026', detail: '' },
      { heading: 'Deloitte Data Analytics Job Simulation', subheading: 'Forage', period: '2026', detail: '' },
      { heading: 'Tata GenAI Powered Data Analytics Job Simulation', subheading: 'Forage', period: '2026', detail: '' },
      { heading: 'JPMorgan Chase Software Engineering Job Simulation', subheading: 'Forage', period: '2026', detail: '' },
      { heading: 'Machine Learning / Deep Learning', subheading: 'Coursera', period: '', detail: '' },
      { heading: 'AWS Cloud Practitioner · Google Cloud Associate · Microsoft SOAR', subheading: 'Various', period: '', detail: '' },
    ],
  },
];

const AccordionSection = ({ section }: { section: typeof resumeSections[0] }) => {
  const [open, setOpen] = useState(true);
  const Icon = section.icon;

  return (
    <div className="border border-white/5 rounded-2xl overflow-hidden bg-brand-bg-lighter">
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center justify-between px-6 py-5 text-left group hover:bg-white/[0.03] transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-brand-accent/10 flex items-center justify-center group-hover:bg-brand-accent/20 transition-colors">
            <Icon size={18} className="text-brand-accent" />
          </div>
          <h3 className="text-lg font-display font-bold text-white">{section.title}</h3>
        </div>
        <ChevronDown
          size={20}
          className={`text-gray-500 transition-transform duration-300 ${open ? 'rotate-180' : ''}`}
        />
      </button>

      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            <div className="px-6 pb-6 space-y-4">
              {section.items.map((item, i) => (
                <div
                  key={i}
                  className="pl-4 border-l-2 border-brand-accent/20 hover:border-brand-accent/60 transition-colors py-1"
                >
                  <div className="flex flex-wrap items-baseline justify-between gap-2 mb-1">
                    <span className="font-semibold text-white text-sm md:text-base">{item.heading}</span>
                    {item.period && (
                      <span className="text-xs text-gray-500 shrink-0">{item.period}</span>
                    )}
                  </div>
                  <p className="text-brand-accent text-xs font-medium mb-1">{item.subheading}</p>
                  {item.detail && <p className="text-gray-400 text-sm leading-relaxed">{item.detail}</p>}
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export const Resume = () => {
  return (
    <section id="resume" className="py-24 bg-brand-bg-lighter/20">
      <div className="max-w-4xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-14"
        >
          <h2 className="text-4xl font-display font-bold mb-4">Resume</h2>
          <p className="text-gray-400 max-w-xl mx-auto mb-8">
            A snapshot of my education, experience, projects, and certifications. 
            Download the full PDF for the complete picture.
          </p>
          <a
            href="/ABDUL_KASHIM_Updated_Resume.pdf"
            download="Abdul_Kashim_Resume.pdf"
            className="inline-flex items-center gap-2 px-7 py-3.5 bg-brand-accent rounded-full font-semibold text-white hover:shadow-[0_0_24px_rgba(255,107,87,0.45)] transition-all"
          >
            <Download size={18} /> Download PDF Resume
          </a>
        </motion.div>

        {/* Accordion sections */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="space-y-4"
        >
          {/* Skills summary bar */}
          <div className="p-6 rounded-2xl bg-brand-bg-lighter border border-white/5 mb-2">
            <p className="text-xs text-gray-500 uppercase tracking-widest font-semibold mb-3">Core Skills</p>
            <div className="flex flex-wrap gap-2">
              {[
                'Python', 'SQL', 'JavaScript', 'React.js', 'Flask', 'Django',
                'TensorFlow', 'Scikit-learn', 'Pandas', 'NumPy', 'D3.js',
                'Docker', 'PostgreSQL', 'MongoDB', 'REST APIs', 'Agile',
              ].map((skill) => (
                <span
                  key={skill}
                  className="px-3 py-1 rounded-full bg-brand-accent/5 text-brand-accent text-xs border border-brand-accent/20"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>

          {resumeSections.map((section) => (
            <AccordionSection key={section.id} section={section} />
          ))}
        </motion.div>
      </div>
    </section>
  );
};
