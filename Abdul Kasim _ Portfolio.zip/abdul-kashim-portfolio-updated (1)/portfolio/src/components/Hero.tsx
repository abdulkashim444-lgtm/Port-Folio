import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Download, ArrowRight } from 'lucide-react';

const roles = ['AI Engineer', 'Full Stack Developer', 'Data Analyst', 'Software Engineer'];

const TypingText = () => {
  const [index, setIndex] = useState(0);
  const [displayText, setDisplayText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const role = roles[index];
    const typingSpeed = isDeleting ? 50 : 150;
    
    const timeout = setTimeout(() => {
      if (!isDeleting && displayText === role) {
        setTimeout(() => setIsDeleting(true), 1500);
      } else if (isDeleting && displayText === '') {
        setIsDeleting(false);
        setIndex((prev) => (prev + 1) % roles.length);
      } else {
        setDisplayText(
          isDeleting 
            ? role.substring(0, displayText.length - 1)
            : role.substring(0, displayText.length + 1)
        );
      }
    }, typingSpeed);

    return () => clearTimeout(timeout);
  }, [displayText, isDeleting, index]);

  return (
    <span className="text-brand-accent border-r-2 border-brand-accent pr-1">
      {displayText}
    </span>
  );
};

export const Hero = () => {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden pt-20">
      {/* Background Glows */}
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-brand-accent/10 rounded-full blur-[120px]" />
      <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-blue-500/10 rounded-full blur-[120px]" />
      
      <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-brand-accent font-display font-medium tracking-widest uppercase mb-4"
          >
            Hello.
          </motion.p>
          <h1 className="text-5xl md:text-7xl font-display font-bold leading-tight mb-6">
            I'm <span className="text-brand-accent">Abdul Kashim</span>
          </h1>
          <h2 className="text-2xl md:text-3xl text-gray-400 font-display mb-8">
            <TypingText />
          </h2>
          <p className="text-gray-400 text-lg mb-10 max-w-lg leading-relaxed">
            Crafting intelligent software solutions with expertise in machine learning, 
            data analytics, and modern web technologies.
          </p>
          
          <div className="flex flex-wrap gap-4">
            <motion.a
              href="#projects"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-4 bg-brand-accent rounded-full font-semibold text-white flex items-center gap-2 hover:shadow-[0_0_20px_rgba(255,107,87,0.4)] transition-all"
            >
              View Projects <ArrowRight size={20} />
            </motion.a>
            <motion.a
              href="/ABDUL_KASHIM_Updated_Resume.pdf"
              download="Abdul_Kashim_Resume.pdf"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-4 border border-gray-700 rounded-full font-semibold text-white flex items-center gap-2 hover:bg-white/5 transition-all text-gray-300"
            >
              Resume <Download size={20} />
            </motion.a>
          </div>

          {/* Social Links */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="flex gap-4 pt-2"
          >
            <a
              href="https://github.com/abdulkashim444-lgtm"
              target="_blank"
              rel="noopener noreferrer"
              className="w-11 h-11 rounded-xl bg-brand-bg-lighter border border-white/10 flex items-center justify-center hover:border-brand-accent hover:text-brand-accent transition-all text-gray-400"
              title="GitHub"
            >
              <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z"/></svg>
            </a>
            <a
              href="https://www.linkedin.com/in/abdul-kashim-567984332"
              target="_blank"
              rel="noopener noreferrer"
              className="w-11 h-11 rounded-xl bg-brand-bg-lighter border border-white/10 flex items-center justify-center hover:border-brand-accent hover:text-brand-accent transition-all text-gray-400"
              title="LinkedIn"
            >
              <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
            </a>
          </motion.div>
        </motion.div>


        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1 }}
          className="relative flex justify-center"
        >
          <div className="w-64 h-64 md:w-80 md:h-80 rounded-full border-2 border-brand-accent/30 flex items-center justify-center relative">
            <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-brand-accent/20 to-blue-500/20 blur-xl animate-pulse" />
            <div className="w-full h-full rounded-full overflow-hidden border-4 border-brand-bg-lighter relative z-10 bg-brand-bg-lighter">
               <img 
                 src="/profile.jpg" 
                 alt="Abdul Kashim" 
                 className="w-full h-full object-cover"
                 referrerPolicy="no-referrer"
                 onLoad={(e) => {
                   const target = e.target as HTMLImageElement;
                   target.style.opacity = '1';
                 }}
                 onError={(e) => {
                   const target = e.target as HTMLImageElement;
                   target.style.display = 'none';
                   const parent = target.parentElement;
                   if (parent && !parent.querySelector('.placeholder')) {
                     const placeholder = document.createElement('div');
                     placeholder.className = "placeholder w-full h-full flex items-center justify-center text-4xl font-display font-bold text-brand-accent";
                     placeholder.innerText = "AK";
                     parent.appendChild(placeholder);
                   }
                 }}
               />
            </div>
            
            {/* Decorative elements */}
            <motion.div 
              animate={{ rotate: 360 }}
              transition={{ repeat: Infinity, duration: 20, ease: "linear" }}
              className="absolute -inset-4 border border-dashed border-gray-700 rounded-full"
            />
          </div>
        </motion.div>
      </div>
      
      {/* Scroll indicator */}
      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 2 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-gray-500"
      >
        <div className="w-px h-12 bg-gradient-to-b from-brand-accent to-transparent" />
      </motion.div>
    </section>
  );
};
