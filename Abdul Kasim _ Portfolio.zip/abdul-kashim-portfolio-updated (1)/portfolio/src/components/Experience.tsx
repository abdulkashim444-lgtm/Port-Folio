import React from 'react';
import { motion } from 'motion/react';
import { Briefcase, Calendar } from 'lucide-react';

const experiences = [
  {
    company: 'Apexsquare Solutions',
    role: 'Front End Developer Intern',
    period: 'Apr 2026 – May 2026',
    description: 'Developed responsive web interfaces using React.js. Integrated frontend components with REST APIs and optimized application performance.',
  },
  {
    company: 'Alfido Tech',
    role: 'Artificial Intelligence Intern',
    period: 'Mar 2026 – Apr 2026',
    description: 'Applied Python, Pandas, and Scikit-learn for exploratory data analysis and predictive modeling. Developed AI-based solutions for real-world use cases.',
  },
  {
    company: 'JPMorgan Chase & Co.',
    role: 'Software Engineering Virtual Experience',
    period: '2026',
    description: 'Worked on REST API integration, Kafka event streaming, and backend service implementation in a virtual job simulation environment.',
  },
  {
    company: 'Quantium',
    role: 'Data Analytics Virtual Intern',
    period: '2026',
    description: 'Performed customer segmentation and purchasing behavior analysis. Generated business insights and strategic recommendations for retail optimization.',
  },
];

export const Experience = () => {
  return (
    <section id="experience" className="py-24">
      <div className="max-w-4xl mx-auto px-6">
        <h2 className="text-4xl font-display font-bold mb-16 text-center">Work Experience</h2>
        
        <div className="relative border-l-2 border-brand-accent/20 pl-8 ml-4 space-y-12">
          {experiences.map((exp, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              {/* Dot */}
              <div className="absolute -left-[41px] top-0 w-5 h-5 rounded-full bg-brand-bg border-4 border-brand-accent shadow-[0_0_10px_rgba(255,107,87,0.5)]" />
              
              <div className="p-6 rounded-2xl bg-brand-bg-lighter border border-white/5 hover:border-brand-accent/30 transition-all">
                <div className="flex flex-wrap justify-between items-start gap-4 mb-4">
                  <div>
                    <h3 className="text-xl font-bold font-display text-white">{exp.role}</h3>
                    <div className="flex items-center gap-2 text-brand-accent mt-1">
                      <Briefcase size={16} />
                      <span className="font-medium">{exp.company}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-gray-500 text-sm">
                    <Calendar size={16} />
                    <span>{exp.period}</span>
                  </div>
                </div>
                <p className="text-gray-400 leading-relaxed text-sm md:text-base">
                  {exp.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
