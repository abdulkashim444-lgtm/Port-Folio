import React from 'react';
import { motion } from 'motion/react';
import { Terminal, Code2, Cpu, Trophy } from 'lucide-react';

const stats = [
  { label: 'Projects Completed', value: '15+', icon: Code2 },
  { label: 'LeetCode Problems', value: '2250+', icon: Terminal },
  { label: 'Certifications', value: '10+', icon: Trophy },
  { label: 'Internships', value: '4', icon: Cpu },
];

export const About = () => {
  return (
    <section id="about" className="py-24 bg-brand-bg-lighter/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="grid grid-cols-2 gap-4"
          >
            {stats.map((stat, idx) => (
              <div 
                key={stat.label}
                className="p-6 bg-brand-bg-lighter rounded-2xl border border-white/5 hover:border-brand-accent/30 transition-all group"
              >
                <stat.icon className="text-brand-accent mb-4 group-hover:scale-110 transition-transform" size={28} />
                <h4 className="text-3xl font-bold text-white mb-1">{stat.value}</h4>
                <p className="text-sm text-gray-400">{stat.label}</p>
              </div>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-display font-bold mb-8">
              Fueling Innovation Through <br /> 
              <span className="text-brand-accent">Code & Analytics</span>
            </h2>
            <div className="space-y-6 text-gray-400 text-lg">
              <p>
                I am a passionate Computer Science student and aspiring Data Scientist/Software Engineer 
                with a knack for turning complex data into actionable insights and robust applications.
              </p>
              <p>
                My journey spans from competitive programming on platforms like LeetCode and Codeforces 
                to building AI-powered systems and scalable full-stack web applications.
              </p>
              <p>
                I thrive in Agile environments and have a proven track record of delivering 
                high-impact solutions during my internships at top organizations.
              </p>
            </div>
            
            <div className="mt-10 flex flex-wrap gap-3">
              {['Python', 'JavaScript', 'SQL', 'React', 'Node.js', 'TensorFlow'].map((tech) => (
                <span 
                  key={tech}
                  className="px-4 py-2 rounded-lg bg-brand-accent/10 border border-brand-accent/20 text-brand-accent text-sm font-medium"
                >
                  {tech}
                </span>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
